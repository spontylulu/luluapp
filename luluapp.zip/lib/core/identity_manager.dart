import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class Identity {
  final String nome;
  final String ruolo;
  final String voce;
  final String tono;
  final Map<String, dynamic> preferenze;

  Identity({
    required this.nome,
    required this.ruolo,
    required this.voce,
    required this.tono,
    required this.preferenze,
  });

  factory Identity.fromJson(Map<String, dynamic> json) {
    return Identity(
      nome: json['nome'],
      ruolo: json['ruolo'],
      voce: json['voce'],
      tono: json['tono'],
      preferenze: json['preferenze'] ?? {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'nome': nome,
      'ruolo': ruolo,
      'voce': voce,
      'tono': tono,
      'preferenze': preferenze,
    };
  }
}

class IdentityManager {
  static const String fileName = 'identita.json';
  static Identity? _identita;

  static Future<String> _getIdentityPath() async {
    final dir = await getApplicationSupportDirectory();
    final configDir = Directory('${dir.path}/LuluData/config');
    if (!configDir.existsSync()) configDir.createSync(recursive: true);
    return '${configDir.path}/$fileName';
  }

  static Future<Identity> loadIdentity() async {
    if (_identita != null) return _identita!;
    final path = await _getIdentityPath();
    final file = File(path);

    if (await file.exists()) {
      final content = await file.readAsString();
      final jsonData = jsonDecode(content);
      _identita = Identity.fromJson(jsonData);
    } else {
      _identita = Identity(
        nome: 'Lulu',
        ruolo: 'Assistente personale di Marco',
        voce: 'femminile',
        tono: 'professionale',
        preferenze: {
          'lingua': 'it',
          'formato_risposte': 'sintetico ma completo'
        },
      );
      await saveIdentity(_identita!);
    }

    return _identita!;
  }

  static Future<void> saveIdentity(Identity nuovaIdentita) async {
    final path = await _getIdentityPath();
    final file = File(path);
    final jsonString = jsonEncode(nuovaIdentita.toJson());
    await file.writeAsString(jsonString);
    _identita = nuovaIdentita;
  }
}
