Write-Host "🚀 Avvio IA Locale Lulu..." -ForegroundColor Cyan

# Avvia Ollama in una finestra visibile
Start-Process powershell -ArgumentList "ollama run llama3.1:8b" -WindowStyle Normal
Start-Sleep -Seconds 2

# Avvia il proxy tramite PM2
Start-Process powershell -ArgumentList "pm2 start llama-proxy.js --name lulu-proxy" -WindowStyle Hidden
Start-Sleep -Seconds 1

# Avvia LocalTunnel direttamente da qui (nessun cd)
Start-Process powershell -ArgumentList "npx localtunnel --port 3001 --subdomain lulu-ai" -WindowStyle Normal

Write-Host "✅ Tutto avviato. IA attiva su https://lulu-ai.loca.lt" -ForegroundColor Green
