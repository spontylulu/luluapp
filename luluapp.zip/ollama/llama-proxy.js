const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const PORT = 3001;
const LLAMA_HOST = 'http://localhost:11434';

console.log('🚀 Avvio Proxy Llama 3.1...');

// Endpoint principale
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, model } = req.body;
    const prompt = messages.map(m => m.content).join('\n');

    const start = Date.now();

    const llamaRes = await axios.post(`${LLAMA_HOST}/api/generate`, {
      model: model || 'llama3.1:8b',
      prompt: `Rispondi sempre in italiano:\n${prompt}`,
      stream: false,
      options: {
        temperature: 0.7,
        top_p: 0.9,
        num_predict: 500
      }
    });

    const elapsed = Date.now() - start;

    res.json({
      message: { content: llamaRes.data.response },
      model: model || 'llama3.1:8b',
      response_time: elapsed
    });
  } catch (err) {
    console.error('❌ Errore proxy:', err.message);
    res.status(500).json({ error: 'Errore proxy', message: err.message });
  }
});

// Test endpoint
app.get('/test', (req, res) => {
  res.json({ status: 'ok', message: 'Proxy attivo' });
});

// Avvio su tutte le interfacce
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🌐 Proxy in ascolto su http://0.0.0.0:${PORT}`);
});

// Blocca chiusura in caso di errori non gestiti
process.on('uncaughtException', function (err) {
  console.error('‼️ Errore NON gestito:', err);
});

process.on('unhandledRejection', function (reason, p) {
  console.error('‼️ Promessa NON gestita:', reason);
});
